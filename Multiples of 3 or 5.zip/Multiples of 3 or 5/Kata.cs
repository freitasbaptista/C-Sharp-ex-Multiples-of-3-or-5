﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multiples_of_3_or_5
{
    class Kata
    {
        public static int Solution(int value)
        {
            int m3 = 3;
            int m5 = 5;
            int aux;
            int resultado = 0;
            int res3;
            int res5;

            if (value < 0)
            {
                return 0;
            }else
            {             
                for (int i = 1; i < value; i++)
                {
                    res3 = i * m3;
                    res5 = i * m5;
                    if (res3 >= value)
                    {
                        res3 = 0;
                    }
                    
                    if (res5 >= value) { 
                    
                        res5 = 0;
                    }
                   
                    if (res3 != res5)
                    {
                     aux  = res3 + res5;
                     resultado += aux;
                      
                    }
                    else
                    {
                        resultado += res3;
                    }
                }
            }
            return resultado;
        }
    }
}
